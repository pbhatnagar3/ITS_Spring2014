import concept_stats
import intelligent_review

me = intelligent_review.intelligent_review("Fall_2013")
print me.concept_lists

